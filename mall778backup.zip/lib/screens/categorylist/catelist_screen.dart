import 'package:flutter/material.dart';

import '../../models/Product.dart';
import 'components/body.dart';
import 'components/custom_app_bar.dart';

class CatelistScreen extends StatelessWidget {
  static String routeName = "/catelist";

  @override
  Widget build(BuildContext context) {
    final CateListArguments agrs =
        ModalRoute.of(context)!.settings.arguments as CateListArguments;
    return Scaffold(
      appBar: AppBar(
        title: Text(agrs.category,style:TextStyle(color: Colors.black)),
        centerTitle: true,
      ),
      body: Body(category: agrs.category),
    );
  }
}

class CateListArguments {
  final String category;

  CateListArguments({required this.category});
}
