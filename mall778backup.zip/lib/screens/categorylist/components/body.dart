import 'package:flutter/material.dart';
import 'package:mall778/components/product_card.dart';
import 'package:mall778/components/productcard.dart';
import 'package:mall778/models/Product.dart';

class Body extends StatelessWidget {

  const Body({Key? key, required String category}) : super(key: key);
  @override
  Widget build(BuildContext context) {
return GridView.count(
        crossAxisCount: 2,
        children: List.generate(
                demoProducts.length,
                (index) {
                  if (demoProducts[index].isPopular)
                    return Productcd(product: demoProducts[index]);

                  return SizedBox
                      .shrink(); // here by default width and height is 0
                },
              ),
    );
  }
}




