import 'package:flutter/material.dart';
import 'package:mall778/constants.dart';
import 'package:mall778/screens/cart/cart_screen.dart';

import '../../../size_config.dart';
import '../../../components/icon_btn_with_counter.dart';
import 'search_field.dart';

class HomeHeader extends StatelessWidget {
  const HomeHeader({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.symmetric(horizontal: getProportionateScreenWidth(10)),
      child: Column(
        children: [
          Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
                    IconBtnWithCounter(
            svgSrc: "assets/icons/menu.svg",
            press: () => Navigator.pushNamed(context, CartScreen.routeName),
          ),
          Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Image.asset(
          "assets/images/logo.png",
          height: getProportionateScreenHeight(40),
          width: getProportionateScreenWidth(40),
        ),
        Text(
          "Mall778",
          style: TextStyle(
            fontSize: getProportionateScreenWidth(25),
            color: kPrimaryColor,
            fontWeight: FontWeight.w400,
          ),
        ),
        ],
      ),
          IconBtnWithCounter(
            svgSrc: "assets/icons/Cart Icon.svg",
            press: () => Navigator.pushNamed(context, CartScreen.routeName),
          ),
          /*IconBtnWithCounter(
            svgSrc: "assets/icons/Bell.svg",
            numOfitem: 3,
            press: () {},
          ),*/
        ],
      ),
      SizedBox(height: getProportionateScreenHeight(10)),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SearchField()
        ],
      )
        ],
      )
    );
  }
}
