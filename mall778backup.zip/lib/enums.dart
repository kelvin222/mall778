enum MenuState { home, cate, service, chat }
